const Product = require("../models/Product");
const Transaction = require("../models/Transaction");
const DailyDiscount = require("../models/DailyDiscount");

exports.createProduct = async (req, res) => {
  console.log("POST masuk ke route");
  try {
    if (!req.file) {
      return res.status(400).json({ message: "IMage si required" });
    }

    const sizes =
      typeof req.body.sizes === "string"
        ? req.body.sizes.split(",").map(Number)
        : req.body.sizes;

    const product = new Product({
      ...req.body,
      sizes,
      image: req.file.path,
      createdBy: req.user?.id || null,
    });
    const saved = await product.save();
    return res.status(201).json(saved);
  } catch (err) {
    console.error("create product error", err);
    return res.status(500).json({ message: "Failed to create product" });
  }
};

exports.getLatestProducts = async (req, res) => {
  try {
    const latestProducts = await Product.find()
      .sort({ createdAt: -1 })
      .limit(9)
      .populate("variants");
    res.json(latestProducts);
  } catch (error) {
    console.error("Failed fecthing latest product", error);
    res.status(500).json({ message: "Error latest product" });
  }
};

exports.getAllProducts = async (req, res) => {
  try {
    const { search } = req.query;

    const filter = {};

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: "i" } },
        { brand: { $regex: search, $options: "i" } },
        { category: { $regex: search, $options: "i" } },
      ];
    }

    const products = await Product.find(filter).populate("variants");
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch products" });
  }
};

exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate("variants");
    if (!product) return res.status(404).json({ message: "Product not found" });

    const discount = await DailyDiscount.findOne({
      productId: product._id,
      expiresAt: { $gt: new Date() },
    });

    const productData = {
      ...product.toObject(),

      discountPercent: discount?.discountPercent || 0,
      discountPrice: discount?.discountPrice || null,
      isDiscount: !!discount,
    };
    res.json(productData);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch product" });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;

    const product = await Product.findById(id);
    if (!product) return res.status(404).json({ message: "Product not found" });

    // Update fields satu per satu
    product.name = req.body.name || product.name;
    product.brand = req.body.brand || product.brand;
    product.price = req.body.price || product.price;
    product.category = req.body.category || product.category;
    product.description = req.body.description || product.description;

    // Ubah sizes dari string ke array number
    if (req.body.sizes) {
      product.sizes = req.body.sizes.split(",").map((s) => parseInt(s.trim()));
    }

    // Jika ada gambar baru diunggah
    if (req.file) {
      product.image = req.file.path;
    }

    await product.save();

    return res.json({ message: "Product updated successfully", product });
  } catch (err) {
    console.error("Update product error:", err);
    res.status(500).json({ message: "Failed to edit product" });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: "Product deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete product" });
  }
};

exports.getBestSellerProducts = async (req, res) => {
  try {
    const bestSellers = await Product.find({
      isBestSeller: true,
    })
      .populate("variants")
      .limit(4);

    res.json(bestSellers);
  } catch (err) {
    console.error("Error fetching best seller", err);

    res.status(500).json({
      message: "Failed get best seller products",
      err: err.message,
    });
  }
};
