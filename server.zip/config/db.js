const mongoose = require("mongoose");
const initCrons = require("../cron");

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MoongoDB connected");
    initCrons();
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
};

module.exports = connectDB;
